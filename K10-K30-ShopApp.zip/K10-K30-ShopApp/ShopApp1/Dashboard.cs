﻿using ShopApp1.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopApp1
{
    public partial class Dashboard : Form
    {
        shopAppEntities db =new shopAppEntities();
        Customer activeCustomer { get; set; }
        public Dashboard(Customer a)
        {
            activeCustomer=a;
            InitializeComponent();
        
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = string.Format("Dear, {0} {1} Xoş gelmisiz", activeCustomer.Firstname, activeCustomer.Surname);
            fillComboCategories();
            FillShoppList(activeCustomer.Id);
            nmMinPrice.Maximum =(int) db.Products.Max(n => n.price);
            nmMaxPrice.Maximum = (int)db.Products.Max(n => n.price);
            fillComboFilterCategories();
        }
        private void fillComboCategories()
        {
            cmbCategory.Items.AddRange(db.Categories.Select(n => n.Name).ToArray());
        }

      
        private void FillComboProducts(int id)
        {
            cmbProduct.Items.Clear();
            cmbProduct.Items.AddRange(db.Products.Where(pr=>pr.Category_id==id ).Select(pr => pr.Name).ToArray());

        }

        private void indexChange(object sender, EventArgs e)
        {
            string categoryName = cmbCategory.Text;
            int categoryId = db.Categories.First(c=>c.Name== categoryName).Id;
            FillComboProducts(categoryId);
        }

        private void CmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            string productName = cmbProduct.Text;
            int price = (int)db.Products.FirstOrDefault(m => m.Name==productName).price;
            lbl_price.Text = "price " + price + " AZN";
            lbl_price.Visible = true;
        }

        private void TxtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if((e.KeyChar<48 || e.KeyChar > 57) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void BtnBuy_Click(object sender, EventArgs e)
        {
            string product = cmbProduct.Text;
            string category = cmbCategory.Text;
            string amount = txtAmount.Text;
            int amounts;
            bool allEmpty = Extensions.isNotEmpty(new string[] {
              product,category,amount
            }, String.Empty);
            if (allEmpty)
            {
                bool changeAmount =int.TryParse(amount, out amounts);
                if (changeAmount)
                {
                    Product selektPro = db.Products.FirstOrDefault(p => p.Name == product);
                    Order ord = new Order();
                    ord.Customer_id = activeCustomer.Id;
                    ord.Product_id = selektPro.Id;
                    ord.Price = selektPro.price;
                    ord.Purchase_date = DateTime.Now;
                    ord.Amount = amounts;
                    db.Orders.Add(ord);
                    db.SaveChanges();
                    MessageBox.Show(product + " " + amount + "Eded");
                    FillShoppList(activeCustomer.Id);
                }
                else
                {
                    lblError.Text = "please amount";
                    lblError.Visible = true;
                }
                
            }
            else
            {
                lblError.Text = "please all the fiel";
                lblError.Visible = true;
            }
        }
        private void FillShoppList(int b)
        {
            DGWiev.DataSource = db.Orders.Where(a=>a.Customer_id==b).Select(pr => new
            {
                pr.Product.Name,
                pr.Product.price,
                pr.Amount,
                pr.Purchase_date
            }).ToList();
        }

        private void CmbCategory_DropDownClosed(object sender, EventArgs e)
        {
            cmbProduct.Text = "";
            lbl_price.Text = "";
            txtAmount.Text = "";
        }
        private void fillComboFilterCategories()
        {
            cmbFilterCategory.Items.Clear();
            cmbFilterCategory.Items.AddRange(db.Orders.Where(or => or.Customer_id == activeCustomer.Id)
                .Select(or => or.Product.Category.Name).Distinct().ToArray());
        }

        private void BtnFilter_Click(object sender, EventArgs e)
        {
            string CategoryName = cmbFilterCategory.Text;
            int minPrice = (int)nmMinPrice.Value;
            int maxPrice = (int)nmMaxPrice.Value;
            int maxAllPrice = (int)db.Products.Max(pr => pr.price);
            if (minPrice > maxPrice || maxPrice == 0)
            {
                maxPrice = maxAllPrice;
            }

            DGWiev.DataSource = db.Orders.Where(or => or.Customer_id == activeCustomer.Id && or.Product.Category.Name.Contains(CategoryName) &&
            or.Product.price <= maxPrice && or.Product.price>=minPrice)
            .Select(or => new
            {
                Product = or.Product.Name,
                Category = or.Product.Category.Name,
                price = or.Price,
                Amount = or.Amount,
                purchase_Date =or.Purchase_date
            }).ToList();

        }
    }
}
